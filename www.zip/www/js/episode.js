var Episode = (function() {

    /**
     * Represents a show.
     * @constructor
     * @param {string} name - The name of the show.
     * @param {object} show - $$ of the show.
     */
    function Episode(show) {
        
        this.latestEpiID = $$(show).data('previousepisode');
        this.nextEpiID = $$(show).data('nextepi') || '0';
        this.showname = $$(show).data('showname');
        this.webChannel = $$(show).data('webchannel') || 'no';
        this.type = JSON.parse(localStorage.getItem('Torry'))[this.showname].type;
        
        if (this.latestEpiID == undefined){
            document.getElementById('tabs').style.display = 'none';
            document.getElementById('LEpisode').style.display = 'none';
            document.getElementById('torrents').innerHTML = '<span style="margin-left:4%;">Will Soon Release.</span>';
        }
        else
           this.getLatestEpisode(); // always get the last epi torrents 

    }
Date.daysBetween = function( date1, date2 ) {
  //Get 1 day in milliseconds
  var one_day=1000*60*60*24;

  // Convert both dates to milliseconds
  var date1_ms = date1.getTime();
  var date2_ms = date2.getTime();
  // Calculate the difference in milliseconds
  var difference_ms = date2_ms - date1_ms;
  //take out milliseconds
  difference_ms = difference_ms/1000;
  var seconds = Math.floor(difference_ms % 60);
  difference_ms = difference_ms/60; 
  var minutes = Math.floor(difference_ms % 60);
  difference_ms = difference_ms/60; 
  var hours = Math.floor(difference_ms % 24);  
  var days = Math.floor(difference_ms/24)+1;
  if (days!=0)
  return days + ' days';
    else
    return 'Out Today!';
}

    /**
     * Adds next wpi details
     *
     * @param {object} o - JSON object of episode.
     */
    function addNextEpisode(o) {
        var today= new Date();
        console.log("adding epi: ", o.name);
        var epiNum = o.season + 'x' + o.number;
        var date = new Date(o.airdate).toLocaleDateString("en-US", {
            month: 'short',
            day: 'numeric',
            year: 'numeric'
        });
        var y2k  = new Date(o.airdate);
        var date1 = new Date(y2k.getFullYear(), y2k.getMonth(), y2k.getDate());

        var nextEpi = '<div class="content-block" style="font-size:18px;color:#fff;margin-bottom:-30px;">' + o.name + '</div>'+
            '<div class="content-block" style="font-size:16px;color:white;margin-bottom:-25px;">Episode ' + epiNum +
            '<div style="width:400px;margin:auto;display:inline;">'+
            '<span style="background:white;color:black;font-weight:bold;padding: 0 5% 0 5%;margin-left:3%;border-radius:5px;">'+date+'</span>'+
            '<span style="background:white;color:black;font-weight:bold;padding: 0 2% 0 2%;margin-left:3%;border-radius:5px;">'+Date.daysBetween(today,date1)+'</span></div></div>'+
            '<div class="content-block" id="summary_block" style="color:#bdbdbd;text-align: justify;">' + (o.summary || 'We dont have a summary for "' +o.name+'" yet. Hang in there!') + '</div>';
        document.getElementById('nextepi').innerHTML = nextEpi;
        myApp.hideIndicator();
    }
    
    /**
     * display Next episode info
     *
     */
    Episode.prototype.getNextEpisode = function() {
        var xhr = new XMLHttpRequest();
        myApp.showIndicator();
        xhr.open("GET", "http://api.tvmaze.com/episodes/" + this.nextEpiID, true);
        xhr.onload = function(e) {
            if (xhr.readyState === 4) {
                if (xhr.status === 200 ) {
                    // add info to current page
                    //console.log(xhr.responseText.match('<iframe>(.*)?<iframe>')
                    addNextEpisode(JSON.parse(xhr.responseText));
                } else {
                    console.error(xhr.statusText);
                }
            }
        };
        xhr.onerror = function(e) {
            myApp.hideIndicator();
            myApp.alert('Check Internet Connection!','Cannot Load');
            console.error(xhr.statusText);
        };
        xhr.send(null);
    };


    /**
     * pad numbers with 2 zeros if needed
     * @param {integer} num - number to pad
     */
    function pad2(num) {
        var s = "0" + num;
        return s.substr(s.length - 2);
    }

    /**
     * get details of latest episode
     * @param {string} param - additional param to add to query
     */
    Episode.prototype.getLatestEpisodeDetails = function(param, exact) {
        $$('#torrents').html(''); // clear current torrents
        myApp.showIndicator();
        var xhr = new XMLHttpRequest();
		var quotes = exact ? '"' : '';
        param = param || '';
        year = 2014;
        var d = new Date();
        var yr = d.getFullYear();
        if (this.showname === "The Flash") {
            xhr.open('GET', 'https://zooqle.com/search?q=' + quotes + encodeURIComponent(this.showname + " " + year + " " + this.epiFormat) + quotes + param + '&fmt=rss', true);
		    console.log('Ajaxing: ' + this.showname + ' ' + this.epiFormat + param +
                    ': https://zooqle.com/search?q=' + quotes + encodeURIComponent(this.showname + " " + year + " " + this.epiFormat) + quotes + param + '&fmt=rss');
        }
        else if (this.showname === 'Jimmy Kimmel Live')
        {
            xhr.open('GET', 'https://zooqle.com/search?q=' + quotes + encodeURIComponent('Jimmy Kimmel' + " " + yr) + quotes + param + '&s=dt&v=t&sd=d&fmt=rss', true);
            console.log('Ajaxing: ' + this.showname + ' ' + param +
                    ': https://zooqle.com/search?q=' + quotes + encodeURIComponent('Jimmy Kimmel' + " " + yr) + quotes + param + '&s=dt&v=t&sd=d&fmt=rss');
        }
        else if (this.showname === 'The Tonight Show Starring Jimmy Fallon')
        {
            xhr.open('GET', 'https://zooqle.com/search?q=' + quotes + encodeURIComponent('Jimmy Fallon' + " " + yr) + quotes + param + '&s=dt&v=t&sd=d&fmt=rss', true);
            console.log('Ajaxing: ' + this.showname + ' ' + param +
                    ': https://zooqle.com/search?q=' + quotes + encodeURIComponent('Jimmy Fallon' + " " + yr) + quotes + param + '&s=dt&v=t&sd=d&fmt=rss');
        }
        else if (this.showname === 'Conan')
        {
            xhr.open('GET', 'https://zooqle.com/search?q=' + quotes + encodeURIComponent('Conan' + " " + yr) + quotes + param + '&s=dt&v=t&sd=d&fmt=rss', true);
            console.log('Ajaxing: ' + this.showname + ' ' + param +
                    ': https://zooqle.com/search?q=' + quotes + encodeURIComponent('Conan' + " " + yr) + quotes + param + '&s=dt&v=t&sd=d&fmt=rss');
        }
        else if (this.type != 'Talk Show' && this.type != 'Game Show' && this.type != 'Sports' && this.type != 'Award Show')
        {
            xhr.open('GET', 'https://zooqle.com/search?q=' + quotes + encodeURIComponent(this.showname + " " + this.epiFormat) + quotes + param + '&fmt=rss', true);
            console.log('Ajaxing: ' + this.showname + ' ' + this.epiFormat + param +
                    ': https://zooqle.com/search?q=' + quotes + encodeURIComponent(this.showname + " " + this.epiFormat) + quotes + param + '&fmt=rss');
        }
        else 
        {
             xhr.open('GET', 'https://zooqle.com/search?q=' + quotes + encodeURIComponent(this.showname) + quotes + param + '&s=dt&v=t&sd=d&fmt=rss', true);
            console.log('Ajaxing: ' + this.showname + ' ' + param +
                    ': https://zooqle.com/search?q=' + quotes + encodeURIComponent(this.showname) + quotes + param + '&s=dt&v=t&sd=d&fmt=rss');
        }
        xhr.onload = function(e) {
            if (xhr.readyState === 4) {
                if (xhr.status === 200) {
                    // no results
                    myApp.hideIndicator();
                    if ($$(xhr.responseXML).find('channel > totalResults').text() === '0') {
                        document.getElementById('torrents').innerHTML = '<span style="margin-left:5%;margin-top:50px;">No torrents found</span>';
                        console.log('no torrents found');
                        return;
                    }
                    for (var i = 0; i < 20; i++) {
                        if (xhr.responseXML.getElementsByTagName('channel')[0].getElementsByTagName('item')[i]) {
                            document.getElementById('torrents').innerHTML +=
                                '<li><a class="external download' + i + ' item-content item-link">'+
                            	'<div class="item-inner"><div class="item-title-row">'+
                                '<div class="item-title" id="torrent_name' + i + '">' +
                                '<span></span></div></div>'+
                                '<div class="item-text" id="torrent_info' + i + '">' +
                                '</div></div></a></li>';

                            $$('#torrent_name' + i).find('span').html(xhr.responseXML.getElementsByTagName('channel')[0].getElementsByTagName('item')[i].getElementsByTagName('title')[0].innerHTML);
                            document.getElementById('torrent_info' + i).innerHTML = 'Seeds: ' + xhr.responseXML.getElementsByTagName('channel')[0].getElementsByTagName('item')[i].getElementsByTagName('seeds')[0].innerHTML +
                                '&emsp;Peers: ' + xhr.responseXML.getElementsByTagName('channel')[0].getElementsByTagName('item')[i].getElementsByTagName('peers')[0].innerHTML +
                                '&emsp;Size: ' + parseInt(xhr.responseXML.getElementsByTagName('channel')[0].getElementsByTagName('item')[i].getElementsByTagName('contentLength')[0].innerHTML / (1024*1024)) + " MB";
                            magnetURL = 'magnet' + xhr.responseXML.getElementsByTagName('channel')[0].getElementsByTagName('item')[i].getElementsByTagName('magnetURI')[0].innerHTML.match('magnet(.*)?]]')[1];
                            $$('.download' + i).attr('href', magnetURL);
                        }
                    }
                } else {
                    console.error(xhr.statusText);
                }
            }
        };
        xhr.onerror = function(e) {
            console.error(xhr.statusText);
        };
        xhr.send(null);

    }

    /**
     * Get latest episode of the show
     *
     */
    var self; // used in tabberHandler
    Episode.prototype.getLatestEpisode = function() {
        var xhr = new XMLHttpRequest();
        myApp.showIndicator();
        xhr.open("GET", "http://api.tvmaze.com/episodes/" + this.latestEpiID, true);
        xhr.onload = function(e) {
            if (xhr.readyState === 4) {
                if (xhr.status === 200) {
                    var res = JSON.parse(xhr.responseText);

                    if (this.webChannel === 'yes' && this.type != 'Reality') {
                        this.epiFormat = "S" + pad2(res.season) + "E*"; // S03E*
						this.getLatestEpisodeDetails();
					} else {
						this.epiFormat = "S" + pad2(res.season) + "E" + pad2(res.number);
						this.getLatestEpisodeDetails('', true);
                    }
					console.log("Latest epi format: " + this.epiFormat);

                    self = this;
                    $$('.toolbar-inner > a').off('click', tabberHandler);
                    $$('.toolbar-inner > a').on('click', tabberHandler);

                } else {
                    console.error(xhr.statusText);
                }
            }
        }.bind(this);
        xhr.onerror = function(e) {
            console.error(xhr.statusText);
        };
        xhr.send(null);
    }

    /**
     * Add handlers for tabbers
     */
    function tabberHandler() {
        $$('.tab-link.active').removeClass('active');
        $$(this).addClass('active');

        var additionalParam = $$(this).data('param') || '';
        if(self.webChannel === 'yes')
        self.getLatestEpisodeDetails(additionalParam);
        else
        self.getLatestEpisodeDetails(additionalParam,true);
    }

    return Episode;
}());