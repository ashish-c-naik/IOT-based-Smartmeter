// Expose globals
var myApp = new Framework7({
    modalTitle: 'Torry',
    material: true,
    tapHold: true
});

// Export selectors engine
var $$ = Dom7;

// Add views
var mainView = myApp.addView('.view-main', {
    // Because we use fixed-through navbar we can enable dynamic navbar
    dynamicNavbar: true
});


function main()  {
    

    

    console.warn('in main yo');
    document.getElementById('trailer_block').style.display = 'none';
    document.getElementById('add-show').addEventListener('click', function(ev) {
        ev.preventDefault();
        var showName = document.getElementById('showname').value;
        document.getElementById('showname').value = "";
        new Show(showName);
    });

    $$('.popup').on('open', function() {
        $$('body').addClass('with-popup');
        $$('.active').removeClass('active');
        $$('.tab1').addClass('active');
    });

    $$('.popup').on('close', function() {
        $$('body').removeClass('with-popup');
        document.getElementById('tabs').style.display = 'block';
        document.getElementById('LEpisode').style.display = 'block';
        document.getElementById('trailer_block').style.display = 'none';
    });

    //RETREIVAL OF SHOWS FROM STORAGE
    var storedShows = JSON.parse(localStorage.getItem('Torry'));
    if (storedShows)
        Object.keys(storedShows).forEach(function(show) {
            console.log(show + " from LS");
            new Show(show);
        });
    window.location.hash = '#Loaded';

    //document.addEventListener("deviceready", function() {
        
            console.log('create ad');
           var admobid = {};
         admobid = { // for Android
                banner: 'ca-app-pub-1598823922727133/7706617603', // or DFP format "/6253334/dfp_example_ad"
                interstitial: 'ca-app-pub-1598823922727133/7706617603'
            };
        AdMob.createBanner({
                    adId: admobid.banner,
                    position: AdMob.AD_POSITION.BOTTOM_CENTER,
                    autoShow: true
                });
        
    //}, false);

}
document.addEventListener("deviceready", main, true);