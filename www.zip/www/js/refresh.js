var RefreshShows = (function() {
    function RefreshShows(name) {
        this.name = name;
        this.Refresh();
    }
   RefreshShows.prototype.Refresh = function() {
        console.log('Refreshing ', this.name);
        var showDetails = {};
        myApp.showIndicator();
        var xhr = new XMLHttpRequest();
        xhr.open("GET", "http://api.tvmaze.com/singlesearch/shows?q="+this.name, true);
        xhr.onload = function() {
            if (xhr.readyState === 4) {
                if (xhr.status === 200 && xhr.responseText) {
                    var res = JSON.parse(xhr.responseText);
                    var current = JSON.parse(localStorage.getItem('Torry'));
                            current[res.name] = res;
                            localStorage.setItem('Torry', JSON.stringify(current));
                            myApp.hideIndicator();
                } else if (xhr.statusText == 'Not Found') {
                    myApp.hideIndicator();
                    myApp.addNotification({
                        message: 'ERROR Refreshing!'
                    });
                } else console.error(xhr.statusText);
            }
            return showDetails;
        }.bind(this);
        xhr.onerror = function() {
            myApp.hideIndicator();
            myApp.alert('Check Internet Connection!','Cannot Load');
            console.log('Ajax error ', showDetails);
            return showDetails;
        };

        xhr.send(null);
    };
    
    return RefreshShows;
})();
