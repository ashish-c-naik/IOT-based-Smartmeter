var addTrailer = (function() {
    function addTrailer(name) {
        this.name = name;
        this.trailer();
    }
    addTrailer.prototype.trailer =function(){
    	console.log("Adding Trailer");
    	var XML = new XMLHttpRequest();
        XML.open("GET", "https://www.tvmaze.com/episodes/" + this.name);
        XML.onload = function(e) {
            if (XML.readyState === 4) {
                if (XML.status === 200 ) {
                    if (XML.responseText.match('<iframe(.*)?src=\"(.*)?..frameborder(.*)?</iframe>') != null) {

            document.getElementById('trailer_block').style.display = 'block';
                    // add video to current page
                    console.log(XML.responseText.match('<iframe(.*)?src=\"(.*)?..frameborder(.*)?</iframe>')[2])
                    document.getElementById('trailer').src = 'https:'+XML.responseText.match('<iframe(.*)?src=\"(.*)?..frameborder(.*)?</iframe>')[2];
                }
                } else {
                    console.error(XML.statusText);
                }
            }
        };
        XML.onerror = function(e) {
            myApp.hideIndicator();
            myApp.alert('Check Internet Connection!','Cannot Load');
            console.error(XML.statusText);
        };
        XML.send(null);
        return;
    };
    return addTrailer;
})();