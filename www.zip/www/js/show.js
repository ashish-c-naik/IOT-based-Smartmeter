var Show = (function() {

    /**
     * Represents a show.
     * @constructor
     * @param {string} name - The name of the show.
     */
    function Show(name) {
        this.name = name;
        localStorage.getItem('Torry') ? '' : localStorage.setItem('Torry', '{}');
        console.log('Create ', this.name)
        this.addShow();
    }

    /**
     * Click handler for each card
     * Show episode and delete shows
     */
    function addClickHandler () {

        // remove prev handlers
        $$('.cover').off('click');
        $$('.cover').off('taphold');

        $$('.cover').on('click', function() {
            myApp.popup('.popup');
            document.getElementById('torrents').innerHTML = '';
            // add bg image to popup
            document.getElementsByClassName('popup')[0].style.background = "linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7))," +
                "url(" + JSON.parse(localStorage.getItem('Torry'))[$$(this).data('showname')].image.original + ") no-repeat";
            document.getElementsByClassName('popup')[0].style.backgroundSize = "cover";
            new addTrailer($$(this).data('nextepi'));
            // create Episode
            var episode = new Episode(this);
            // next episode? add the details
            if ($$(this).data('nextepi')) {
                episode.getNextEpisode(); // latest and next
            } else { // only latest
                var nextEpi = '<div class="content-block" style="font-size:18px;color:#fff;">' + 'TBA' + '</div>'+
                  '<div class="content-block" id="summary_block" style="color:#bdbdbd;margin-top:-28px;text-align: justify;">' +'We dont have a summary for TBA yet. Hang in there!' + '</div>';
                document.getElementById('nextepi').innerHTML = nextEpi;
            }
            if (JSON.parse(localStorage.getItem('Torry'))[$$(this).data('showname')].webChannel != null) {
            	var nextEpi ='<div id="summary_block" style="color:#bdbdbd;margin-top:-28px;text-align: justify;">' + JSON.parse(localStorage.getItem('Torry'))[$$(this).data('showname')].summary+ '</div>';
                document.getElementById('summary_block').innerHTML = nextEpi;
            }
        });
        // Delete shows
        $$('.cover').on('taphold', function() {
            myApp.confirm("Do you want to remove " + $$(this).data('showname') + " from this listing?", "Delete?", function() {
                $$(this).remove();
                var current = JSON.parse(localStorage.getItem('Torry'));
                delete current[$$(this).data('showname')]
                localStorage.setItem('Torry', JSON.stringify(current));
                console.log("Deleted:", $$(this).data('showname'));
            }.bind(this));
        });

    }

    /**
     * Creates the show card.
     *
     * @param {o} o - JSON info of show ajaxed or stored
     */
    var createImage = function(o) {
        if (Object.keys(o).length === 0) return; // Empty {}

        var next = o['_links'].nextepisode ? o['_links'].nextepisode.href.match(/\d+/)[0] : '';
        var previous = o['_links'].previousepisode ? o['_links'].previousepisode.href.match(/\d+/)[0] : '';

        if (o.image) {
            var img = '<div  class="col-33 cover" data-name="' + o.name + '" data-nextepi="' + next + '" data-showname="' + o.name + '"' + '" data-previousepisode="' + previous + '"' + ' style="">' +
			'<img src="' + o.image.medium + '" name="' + o.name + '" style="width:100%;margin-bottom:-6px;"></a></div>';
        }

        document.getElementById('show-pics').innerHTML += img;
        document.getElementById('loading').style.display = 'none';
        addClickHandler(this.name);
    };

    /**
     * Ajax GET the show and save in LS
     *
     * @returns Promise JSON of the show as response
     */
    Show.prototype.ajaxShow = function() {
        console.log('Ajaxing: ', this.name);
        myApp.showIndicator();

        return new Promise(function(resolve, reject) {
            var xhr = new XMLHttpRequest();
            xhr.open("GET", "http://api.tvmaze.com/singlesearch/shows?q=" + this.name, true);

            xhr.onload = function() {
                if (xhr.readyState === 4) {
                    if (xhr.status === 200 && xhr.responseText) {

                        var res = JSON.parse(xhr.responseText);
                        console.log('Ajax got', res);
                        if ($$('[data-showname="' + res.name + '"]').length) {
                            myApp.hideIndicator();
                            myApp.addNotification({
                                message: res.name + ' already added!'
                            });
                            console.log(res.name, " already added");
                        } else if (res.status == 'Running' || res.status == 'In Development' || res.status == 'To Be Determined') {
                            // if still running, create and store
                            var current = JSON.parse(localStorage.getItem('Torry'));
                            current[res.name] = res;
                            localStorage.setItem('Torry', JSON.stringify(current));
                            myApp.hideIndicator();
                            resolve(res);
                        } else if (res.status == 'Ended') {
                            myApp.hideIndicator();
                            myApp.addNotification({
                                message: res.name + ' has ended!'
                            });
                            reject(Error("Show ended"));
                        } 

                    } else if (xhr.statusText == 'Not Found') {
                        myApp.hideIndicator();
                        myApp.addNotification({
                            message: this.name + ' was not Found!'
                        });
                    } else console.error(xhr.statusText);
                }
            }.bind(this);

            xhr.onerror = function() {
                myApp.hideIndicator();
                myApp.alert('Check Internet Connection!','Cannot Load');
                console.log('Ajax error ', showDetails);
            };

            xhr.send(null);
        }.bind(this));
    };

    /**
     * Add show to the main page
     *
     */
    Show.prototype.addShow = function() {
		if ($$('[data-showname="' + this.name + '"]').length) {
            myApp.hideIndicator();
			myApp.addNotification({
                message: this.name + ' already added!'
            });
			console.log(this.name, " already there")
            return;
		}
        this.ajaxShow().then(function(response) {
            createImage(response);
        });
    };

    return Show;

})();
